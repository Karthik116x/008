
  # AI Agricultural Decision Support

  This is a code bundle for AI Agricultural Decision Support. The original project is available at https://www.figma.com/design/qcwAo8VFpsjmEORqnGjkKz/AI-Agricultural-Decision-Support.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  